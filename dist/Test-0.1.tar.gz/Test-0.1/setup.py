from setuptools import setup

setup(
    # Whatever arguments you need/want
    name='Test',
    url='https://github.com/sarwarhamza/hello-world',
    version='0.1',
)